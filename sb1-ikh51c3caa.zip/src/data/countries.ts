import { FileText, Globe, Clock, Award } from 'lucide-react';

export interface Program {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  requirements: string[];
  requirementsAr: string[];
  benefits: string[];
  benefitsAr: string[];
  timeline: string;
  timelineAr: string;
}

export interface Country {
  id: string;
  name: string;
  nameAr: string;
  flagUrl: string;
  imageUrl: string;
  description: string;
  descriptionAr: string;
  programs: Program[];
}

export const countries: Country[] = [
  {
    id: 'canada',
    name: 'Canada Immigration',
    nameAr: 'الهجرة إلى كندا',
    flagUrl: 'https://flagcdn.com/ca.svg',
    imageUrl: 'https://images.pexels.com/photos/2837909/pexels-photo-2837909.jpeg',
    description: 'Start your new life in Canada with our comprehensive immigration programs.',
    descriptionAr: 'ابدأ حياتك الجديدة في كندا مع برامج الهجرة الشاملة لدينا',
    programs: [
      {
        id: 'express-entry',
        title: 'Express Entry Program',
        titleAr: 'برنامج الدخول السريع',
        description: 'Fast-track immigration program for skilled workers.',
        descriptionAr: 'برنامج هجرة سريع للعمال المهرة',
        requirements: [
          'Language proficiency (English/French)',
          'Education assessment',
          'Work experience',
          'Proof of funds'
        ],
        requirementsAr: [
          'إتقان اللغة (الإنجليزية/الفرنسية)',
          'تقييم التعليم',
          'خبرة العمل',
          'إثبات التمويل'
        ],
        benefits: [
          'Permanent residency',
          'Access to healthcare',
          'Work and study rights',
          'Path to citizenship'
        ],
        benefitsAr: [
          'الإقامة الدائمة',
          'الوصول إلى الرعاية الصحية',
          'حقوق العمل والدراسة',
          'طريق للحصول على الجنسية'
        ],
        timeline: '6-12 months processing time',
        timelineAr: '6-12 شهر وقت المعالجة'
      }
    ]
  },
  {
    id: 'georgia',
    name: 'Georgia Tourism Program',
    nameAr: 'برنامج جورجيا السياحي',
    flagUrl: 'https://flagcdn.com/ge.svg',
    imageUrl: 'https://images.pexels.com/photos/5087165/pexels-photo-5087165.jpeg',
    description: 'Experience an unforgettable journey with our comprehensive Georgia tourism program.',
    descriptionAr: 'استمتع برحلة لا تُنسى مع خدمات متكاملة ومميزة في جورجيا',
    programs: [
      {
        id: 'georgia-tourism',
        title: '5-Day Georgia Tourism Package',
        titleAr: '✈️ برنامج جورجيا السياحي – 5 أيام أو أكثر 🇬🇪',
        description: 'Comprehensive tourism package with all-inclusive services.',
        descriptionAr: `استمتع برحلة لا تُنسى مع خدمات متكاملة ومميزة:

✅ الاستقبال والتوديع من وإلى المطار
✅ حجوزات فنادق راقية مع وجبة إفطار يومية مفتوحة
✅ جولات سياحية يومية حسب البرنامج
✅ سيارة سياحية خاصة للتنقلات اليومية – خصوصية وراحة تامة لك ولعائلتك أو أصدقائك
✅ سائق محترف طوال فترة الرحلة
✅ خط اتصال مع باقة إنترنت لكل فرد
✅ تأمين سفر دولي شامل
✅ السعر شامل لجميع الضرائب
✈️ تذاكر الطيران حسب نوع العرض
🍽️ وجبات الغداء والعشاء حسب العرض – مع التوصيل إلى أحد المطاعم التركية أو العربية حسب اختياركم

📍 اختر برنامجك الآن وابدأ رحلتك إلى جورجيا بكل راحة وثقة!`,
        requirements: [
          'Valid passport',
          'Travel insurance',
          'Booking confirmation'
        ],
        requirementsAr: [
          'جواز سفر ساري المفعول',
          'تأمين سفر',
          'تأكيد الحجز'
        ],
        benefits: [
          'Airport transfers',
          'Daily breakfast',
          'Private transportation',
          'Professional driver',
          'Internet package',
          'Travel insurance',
          'All taxes included'
        ],
        benefitsAr: [
          'خدمة التوصيل من وإلى المطار',
          'إفطار يومي',
          'مواصلات خاصة',
          'سائق محترف',
          'باقة إنترنت',
          'تأمين سفر',
          'شامل جميع الضرائب'
        ],
        timeline: '5 days or more, flexible according to your preferences',
        timelineAr: '5 أيام أو أكثر، مرنة حسب تفضيلاتك'
      }
    ]
  },
  {
    id: 'malta',
    name: 'Malta Work Opportunities',
    nameAr: 'فرص العمل في مالطا',
    flagUrl: 'https://flagcdn.com/mt.svg',
    imageUrl: 'https://images.pexels.com/photos/4388164/pexels-photo-4388164.jpeg',
    description: 'Explore exciting job opportunities in Malta across various sectors.',
    descriptionAr: 'اكتشف فرص عمل مثيرة في مالطا في مختلف القطاعات',
    programs: [
      {
        id: 'malta-jobs',
        title: 'Malta Employment Program',
        titleAr: 'برنامج التوظيف في مالطا',
        description: 'Various job opportunities including positions in hospitality, driving, and service sectors.',
        descriptionAr: 'فرص عمل متنوعة تشمل وظائف في مجالات الضيافة والسياقة وقطاعات الخدمات',
        requirements: [
          'Valid passport',
          'Relevant work experience',
          'Basic English language skills',
          'Clean driving record (for driver positions)'
        ],
        requirementsAr: [
          'جواز سفر ساري المفعول',
          'خبرة عمل ذات صلة',
          'مهارات أساسية في اللغة الإنجليزية',
          'سجل قيادة نظيف (لوظائف السائقين)'
        ],
        benefits: [
          'Competitive salary',
          'Work permit assistance',
          'Accommodation support',
          'Healthcare coverage',
          'Professional development'
        ],
        benefitsAr: [
          'راتب تنافسي',
          'المساعدة في تصريح العمل',
          'دعم السكن',
          'تغطية الرعاية الصحية',
          'التطوير المهني'
        ],
        timeline: '2-3 months processing time',
        timelineAr: '2-3 أشهر وقت المعالجة'
      }
    ]
  },
  {
    id: 'western-europe',
    name: 'Western Europe',
    nameAr: 'أوروبا الغربية',
    flagUrl: 'https://flagcdn.com/eu.svg',
    imageUrl: 'https://images.pexels.com/photos/532263/pexels-photo-532263.jpeg',
    description: 'Explore opportunities in Western European countries with our immigration services.',
    descriptionAr: 'اكتشف الفرص في دول أوروبا الغربية مع خدمات الهجرة لدينا',
    programs: [
      {
        id: 'skilled-migration',
        title: 'Skilled Migration Program',
        titleAr: 'برنامج هجرة العمالة الماهرة',
        description: 'Immigration pathways for skilled professionals in Western Europe.',
        descriptionAr: 'مسارات الهجرة للمهنيين المهرة في أوروبا الغربية',
        requirements: [
          'Professional qualifications',
          'Work experience',
          'Language proficiency',
          'Job offer (in some cases)'
        ],
        requirementsAr: [
          'المؤهلات المهنية',
          'خبرة العمل',
          'إتقان اللغة',
          'عرض عمل (في بعض الحالات)'
        ],
        benefits: [
          'Residency permits',
          'Family reunification',
          'Social security access',
          'Career development'
        ],
        benefitsAr: [
          'تصاريح الإقامة',
          'لم شمل العائلة',
          'الوصول إلى الضمان الاجتماعي',
          'التطور المهني'
        ],
        timeline: '3-6 months processing time',
        timelineAr: '3-6 أشهر وقت المعالجة'
      }
    ]
  },
  {
    id: 'eastern-europe',
    name: 'Eastern Europe',
    nameAr: 'أوروبا الشرقية',
    flagUrl: 'https://flagcdn.com/eu.svg',
    imageUrl: 'https://images.pexels.com/photos/2346216/pexels-photo-2346216.jpeg',
    description: 'Discover opportunities in Eastern European countries with growing economies.',
    descriptionAr: 'اكتشف الفرص في دول أوروبا الشرقية ذات الاقتصادات المتنامية',
    programs: [
      {
        id: 'work-residence',
        title: 'Work and Residence Program',
        titleAr: 'برنامج العمل والإقامة',
        description: 'Combined work and residence permits for Eastern European countries.',
        descriptionAr: 'تصاريح عمل وإقامة مجمعة لدول أوروبا الشرقية',
        requirements: [
          'Valid passport',
          'Professional qualifications',
          'Basic language skills',
          'Clean criminal record'
        ],
        requirementsAr: [
          'جواز سفر ساري المفعول',
          'المؤهلات المهنية',
          'مهارات لغوية أساسية',
          'سجل جنائي نظيف'
        ],
        benefits: [
          'Work permit',
          'Residence permit',
          'Healthcare access',
          'Education opportunities'
        ],
        benefitsAr: [
          'تصريح عمل',
          'تصريح إقامة',
          'الوصول إلى الرعاية الصحية',
          'فرص تعليمية'
        ],
        timeline: '2-4 months processing time',
        timelineAr: '2-4 أشهر وقت المعالجة'
      }
    ]
  },
  {
    id: 'australia',
    name: 'Australia Jobs',
    nameAr: 'وظائف أستراليا',
    flagUrl: 'https://flagcdn.com/au.svg',
    imageUrl: 'https://images.pexels.com/photos/1878293/pexels-photo-1878293.jpeg',
    description: 'Find job opportunities and work visas for Australia.',
    descriptionAr: 'ابحث عن فرص العمل وتأشيرات العمل في أستراليا',
    programs: [
      {
        id: 'australia-jobs',
        title: 'Australia Employment Program',
        titleAr: 'برنامج التوظيف في أستراليا',
        description: 'Job opportunities and visa sponsorship for skilled workers in Australia.',
        descriptionAr: 'فرص عمل وكفالة تأشيرات للعمال المهرة في أستراليا',
        requirements: [
          'Relevant qualifications',
          'Work experience',
          'English proficiency',
          'Skills assessment'
        ],
        requirementsAr: [
          'المؤهلات ذات الصلة',
          'خبرة العمل',
          'إتقان اللغة الإنجليزية',
          'تقييم المهارات'
        ],
        benefits: [
          'Competitive salaries',
          'Work visa sponsorship',
          'Career growth opportunities',
          'Access to healthcare'
        ],
        benefitsAr: [
          'رواتب تنافسية',
          'كفالة تأشيرة العمل',
          'فرص النمو المهني',
          'الوصول إلى الرعاية الصحية'
        ],
        timeline: '3-6 months processing time',
        timelineAr: '3-6 أشهر وقت المعالجة'
      }
    ]
  }
];

export const getCountryById = (id: string): Country | undefined => {
  return countries.find(country => country.id === id);
};